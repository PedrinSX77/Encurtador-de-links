const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');
const container = document.getElementById('lista-links');
const noLinksMsg = document.getElementById('no-links');